SELECT * FROM dataspark.customerdatatable;
SELECT ProductKey, Gender, Age, City, State, Country, Continent from dataspark.customerdatatable;

-- Customer analysis -- 
CREATE TABLE dataspark.CustomerAnalysis
AS 
SELECT ProductKey, Gender, Age, City, State, Country, Continent from dataspark.customerdatatable;
commit;
SELECT * FROM dataspark.CustomerAnalysis;

-- Male customer dertails --
CREATE TABLE dataspark.CustomerAnalysisMale
AS 
SELECT ProductKey, Gender, Age, City, State, Country, Continent from dataspark.CustomerAnalysis 
WHERE Gender = 'Male';
commit;
SELECT * FROM dataspark.CustomerAnalysisMale;

-- Female customer dertails --
CREATE TABLE dataspark.CustomerAnalysisFemale
AS 
SELECT ProductKey, Gender, Age, City, State, Country, Continent from dataspark.CustomerAnalysis 
WHERE Gender = 'Female';
commit;
SELECT * FROM dataspark.CustomerAnalysisFemale;


-- lead product key and product name--
SELECT * FROM dataspark.customerdatatable;
SELECT OrderNumber, ProductName, ProductKey, Quantity, OrderDate, LEAD(ProductKey) OVER (ORDER BY OrderNumber ASC) "LEAD_ProductKey" from dataspark.customerdatatable;


/*SELECT * FROM (
SELECT RANK() OVER (order by ProductName DESC) "Product_RANK", ProductName
FROM dataspark.customerdatatable
)AS T1;
commit;

SELECT Product_RANK, COUNT(Product_RANK) FROM (
SELECT RANK() OVER (order by ProductName DESC) "Product_RANK", ProductName, Brand, Quantity
FROM dataspark.customerdatatable
)AS T1
GROUP BY Product_RANK
HAVING COUNT (Product_RANK)>=1; 
*/

-- Product name and product count -- 
SELECT ProductName, COUNT(ProductName) "Product COUNT" from dataspark.customerdatatable
GROUP BY ProductName
HAVING COUNT(ProductName) <> 0;

-- Average sales data--
SELECT CustomerKey, ProductName, AVG(DISTINCT Quantity) AS "AvgSales"
FROM dataspark.customerdatatable
GROUP BY CustomerKey;

-- Sales Analysis -- 
SELECT * FROM dataspark.customerdatatable;
select count(OrderNumber) from dataspark.customerdatatable;

-- quantity wise order details--
SELECT * FROM (
SELECT Quantity, COUNT(OrderNumber) Order_Count FROM dataspark.customerdatatable
GROUP BY Quantity
) AS TAB
WHERE Order_Count >= 1 ;

-- store based order count -- 
SELECT * FROM (
SELECT StoreKey, COUNT(OrderNumber) Order_Count FROM dataspark.customerdatatable
GROUP BY StoreKey
) AS TAB2
WHERE Order_Count >= 1 ;

SELECT * FROM dataspark.customerdatatable;

SELECT OrderNumber, UnitCostUSD, UnitPriceUSD, Exchange, CurrencyCode FROM dataspark.customerdatatable;


-- lead lag-- 

-- LEAD ---
SELECT ProductKey, ProductName, OrderNumber, LEAD(OrderNumber) OVER (ORDER BY OrderNumber ASC) "LEAD_Product"
FROM dataspark.customerdatatable;

SELECT ProductKey, ProductName, OrderNumber, LEAD(OrderNumber) OVER (ORDER BY OrderNumber ASC) "LEAD_Product", LEAD (OrderNumber) OVER (ORDER BY OrderNumber ASC) - OrderNumber "DIFF"
FROM dataspark.customerdatatable;

-- LAG ------
SELECT ProductKey, OrderNumber, LEAD(ProductKey) OVER (ORDER BY ProductKey ASC) "LEAD_Product", LEAD (ProductKey) OVER (ORDER BY ProductKey ASC) - ProductKey "DIFF",
ProductKey,  LAG(ProductKey) OVER (order by ProductKey ASC) "LAG Product"
FROM dataspark.customerdatatable;
