import streamlit as st
import pandas as pd
from streamlit_option_menu import option_menu

st.set_page_config(page_title= "Redbus Information", layout= "wide")
st.write("This is my page context")
with st.sidebar:
    
    st.sidebar.image("img.jpeg", use_column_width= True)
    
    menu = option_menu(
    
                menu_title = "Select Any Menu",
                options = ["Bus Information"],
                styles = {
                    "nav-link-selected": {"background-color": "green"}
                }
    )

if menu == "Bus Information":
    c1, c2, c3, c4 = st.columns(4)

    data = pd.read_csv("DataNw.csv")

    with c1:
        selected_columns = st.multiselect("select any columns",data.columns)
    with c2:
        selected_state = st.selectbox("select State",data['State'].unique())

    st.table(data[data['State'].isin([selected_state])][selected_columns])   # data[data['Education'] == "Masters"][['Age', "city", "Edcation"]]

    with c3:
        selected_route = st.selectbox("select Route",data['Routes'].unique())
   
    st.table(data[data['Routes'].isin([selected_route])][selected_columns])   # data[data['Education'] == "Masters"][['Age', "city", "Edcation"]]

    with c4:
        selected_rating = st.selectbox("select Rating",data['Rating'].unique())
    
    #st.table(data[data['Rating'].isin([selected_rating])][selected_columns])  
    st.table(data[data['Rating'] <=3])  
  
